package org.sk.security.demo.db.entities;

public interface EntityConverter <T> {
	 public T getEntity( int id);
	}