package org.sk.security.demo.db.entities;

public interface DtoConvertor<R> {
	public R getDto();
}
